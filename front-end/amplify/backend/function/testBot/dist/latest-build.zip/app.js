/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/




var express = require('express')
const axios = require('axios');
var bodyParser = require('body-parser')
var awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')

const TELEGRAM_URL = 'https://api.telegram.org/bot'
const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN

// declare a new express app
var app = express()
app.use(bodyParser.json())
app.use(awsServerlessExpressMiddleware.eventContext())

// Enable CORS for all methods
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Headers", "*")
  next()
})


/**********************
 * Bot handler *
 **********************/
async function getConfig() {
   // get config from graphql
}

async function sendToUser(chat_id, text) {
  return await axios({
    url: `${TELEGRAM_URL}${TELEGRAM_TOKEN}/sendMessage`,
    method: 'POST',
    data: {
      chat_id,
      text
    }
  })
}

app.post('/', async (req, res) => {
  const chatId = req.body.message.chat.id
  const sentMessage = req.body.message.text
  // do stuff
  // respond
  await sendToUser(chatId, sentMessage)
  res.sendStatus(200)
  //res.status(200).send({})

  // Add your code here
  //res.json({success: 'post call succeed!', chatID: chat.id, text})
  //res.sendStatus(200)
})

/****************************
* Example methods *
****************************/
/*
app.get('/item', function(req, res) {
  // Add your code here
  res.json({success: 'get call succeed!', url: req.url})
})
app.post('/item/*', function(req, res) {
  // Add your code here
  res.json({success: 'post call succeed!', url: req.url, body: req.body})
})
*/

/****************************
* Start app *
****************************/

app.listen(3000, function() {
    console.log("App started")
})

// Export the app object. When executing the application local this does nothing. However,
// to port it to AWS Lambda we will create a wrapper around that will load the app from
// this file
module.exports = app
